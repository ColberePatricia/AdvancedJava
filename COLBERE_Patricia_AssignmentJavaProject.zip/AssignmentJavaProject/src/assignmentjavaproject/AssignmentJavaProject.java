/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package assignmentjavaproject;

/**
 * Class to show the main frame
 * 
 * @author Patricia
 */
public class AssignmentJavaProject {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        
        MainFrame myFrame = new MainFrame();
        myFrame.setSize(900, 830);

	myFrame.setVisible(true);
    }
    
}
